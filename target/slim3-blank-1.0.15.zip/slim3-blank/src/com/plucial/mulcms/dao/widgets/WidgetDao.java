package com.plucial.mulcms.dao.widgets;

import org.slim3.datastore.DaoBase;

import com.plucial.mulcms.model.widgets.Widget;

public class WidgetDao extends DaoBase<Widget>{

}
