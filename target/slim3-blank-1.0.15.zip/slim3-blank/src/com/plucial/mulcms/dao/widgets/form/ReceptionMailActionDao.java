package com.plucial.mulcms.dao.widgets.form;

import org.slim3.datastore.DaoBase;

import com.plucial.mulcms.model.widgets.form.ReceptionMailAction;

public class ReceptionMailActionDao extends DaoBase<ReceptionMailAction>{
    
    /** META */
//    private static final ReceptionMailActionMeta meta = ReceptionMailActionMeta.get();
}
