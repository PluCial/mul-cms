package com.plucial.mulcms.model.widgets;

import java.io.Serializable;

import org.slim3.datastore.Model;

import com.plucial.mulcms.model.Rendering;

@Model(schemaVersion = 1)
public class Widget extends Rendering implements Serializable {

    private static final long serialVersionUID = 1L;

}
